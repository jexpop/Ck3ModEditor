import os
import json
import time
from utils.file_ops import backup_item, process_folder

MODULES_FILE = "modules.json"


def load_modules():
    with open(MODULES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def write_log(profile_name, module_name, lines):
    log_dir = os.path.join("logs", profile_name)
    os.makedirs(log_dir, exist_ok=True)

    # Convertir nombre del módulo en nombre de archivo válido
    safe_name = module_name.replace("/", "__")

    log_path = os.path.join(log_dir, f"{safe_name}.log")

    with open(log_path, "a", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")



def process_module(game_key, module_key, game_root, mod_root, backup_root, offset, profile_name):
    modules = load_modules()

    if game_key not in modules:
        raise ValueError(f"Juego no definido en modules.json: {game_key}")

    game_modules = modules[game_key]

    if module_key not in game_modules:
        raise ValueError(f"Módulo no definido: {module_key}")

    cfg = game_modules[module_key]

    rel_path = cfg["path"]
    ignore_ext = cfg.get("ignore_ext", [])

    src = os.path.join(game_root, rel_path)
    dst = os.path.join(mod_root, rel_path)

    if not os.path.isdir(src):
        raise FileNotFoundError(f"No existe: {src}")

    start = time.time()

    # Backup único
    backup_item(src, backup_root, game_root)

    # Procesado
    modified_files = process_folder(src, dst, offset, ignore_ext=ignore_ext)

    end = time.time()

    # Log
    log_lines = [
        f"=== {module_key} ===",
        f"Fecha: {time.ctime()}",
        f"Origen: {src}",
        f"Destino: {dst}",
        f"Offset aplicado: {offset}",
        f"Extensiones ignoradas: {ignore_ext}",
        f"Archivos modificados: {len(modified_files)}",
        f"Tiempo total: {end - start:.2f} segundos",
        ""
    ]

    write_log(profile_name, module_key, log_lines)

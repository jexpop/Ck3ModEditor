import re

DATE_REGEX = re.compile(r"(\b)(\d{1,4})(\.\d{1,2}\.\d{1,2}\b)")


def apply_year_offset(text, offset):
    def repl(match):
        prefix, year, rest = match.groups()
        new_year = int(year) + offset
        return f"{prefix}{new_year}{rest}"
    return DATE_REGEX.sub(repl, text)

import json
import os

PROFILES_FILE = "profiles.json"


def load_profiles():
    """Carga todos los perfiles desde profiles.json."""
    if not os.path.exists(PROFILES_FILE):
        return []

    with open(PROFILES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_profiles(profiles):
    """Guarda la lista completa de perfiles."""
    with open(PROFILES_FILE, "w", encoding="utf-8") as f:
        json.dump(profiles, f, indent=4)


def get_profile(name):
    """Devuelve un perfil por nombre."""
    profiles = load_profiles()
    for p in profiles:
        if p["name"] == name:
            return p
    return None


def add_profile(profile):
    """Añade un nuevo perfil."""
    profiles = load_profiles()
    profiles.append(profile)
    save_profiles(profiles)


def update_profile(updated_profile):
    """Actualiza un perfil existente."""
    profiles = load_profiles()
    for i, p in enumerate(profiles):
        if p["name"] == updated_profile["name"]:
            profiles[i] = updated_profile
            save_profiles(profiles)
            return
    raise ValueError(f"Perfil no encontrado: {updated_profile['name']}")


def delete_profile(name):
    """Elimina un perfil por nombre."""
    profiles = load_profiles()
    profiles = [p for p in profiles if p["name"] != name]
    save_profiles(profiles)


def list_profiles():
    """Devuelve una lista con los nombres de los perfiles."""
    return [p["name"] for p in load_profiles()]

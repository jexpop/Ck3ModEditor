import os
import shutil
from utils.date_ops import apply_year_offset


def backup_item(src_path, backup_root, game_root):
    rel = os.path.relpath(src_path, game_root)
    backup_path = os.path.join(backup_root, rel)

    if os.path.exists(backup_path):
        shutil.rmtree(backup_path)

    shutil.copytree(src_path, backup_path)

    return backup_path


def process_file(src_path, dst_path, offset):
    try:
        with open(src_path, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(src_path, "r", encoding="latin-1") as f:
            content = f.read()

    new_content = apply_year_offset(content, offset)

    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    with open(dst_path, "w", encoding="utf-8") as f:
        f.write(new_content)


def process_folder(src, dst, offset, ignore_ext=None):
    ignore_ext = ignore_ext or []
    modified = []

    for root, _, files in os.walk(src):
        for file in files:
            if any(file.endswith(ext) for ext in ignore_ext):
                continue

            if file.endswith((".txt", ".yml")):
                src_file = os.path.join(root, file)
                rel_path = os.path.relpath(src_file, src)
                dst_file = os.path.join(dst, rel_path)

                process_file(src_file, dst_file, offset)
                modified.append(rel_path)

    return modified

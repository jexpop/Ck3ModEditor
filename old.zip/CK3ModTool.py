import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import os
import difflib
import json

from utils.profile_ops import (
    load_profiles, save_profiles, get_profile,
    add_profile, update_profile, list_profiles
)

from core.processor import load_modules, process_module


class ModToolApp:
    def __init__(self, root):
        self.root = root
        root.title("Mod Tool - Multi Juego")

        self.profiles = load_profiles()
        self.modules = load_modules()

        self.current_profile = None
        self.module_vars = {}

        # Para validación
        self.validation_diffs = {}
        self.full_validation_diffs = {}
        self.full_validation_details = {}

        self.build_ui()

    # ---------------------------------------------------------
    # UI PRINCIPAL
    # ---------------------------------------------------------
    def build_ui(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True)

        self.tab_profiles = ttk.Frame(notebook)
        self.tab_processing = ttk.Frame(notebook)
        self.tab_validation = ttk.Frame(notebook)

        notebook.add(self.tab_profiles, text="Perfil")
        notebook.add(self.tab_processing, text="Fechas")
        notebook.add(self.tab_validation, text="Validación")

        self.build_profiles_tab()
        self.build_processing_tab()
        self.build_validation_tab()

    # ---------------------------------------------------------
    # TAB PRINCIPAL: PERFIL
    # ---------------------------------------------------------
    def build_profiles_tab(self):
        frame = self.tab_profiles

        tk.Label(frame, text="Seleccionar perfil:").pack()
        self.profile_combo = ttk.Combobox(
            frame, values=list_profiles(), state="readonly"
        )
        self.profile_combo.pack()
        self.profile_combo.bind("<<ComboboxSelected>>", self.on_profile_selected)

        self.entry_game_root = self._add_path_selector(frame, "Raíz del juego")
        self.entry_mod_root = self._add_path_selector(frame, "Raíz del mod")
        self.entry_backup_root = self._add_path_selector(frame, "Carpeta de backups")

        tk.Button(frame, text="Guardar perfil", command=self.save_profile).pack(pady=5)
        tk.Button(frame, text="Crear perfil nuevo", command=self.create_profile).pack(pady=5)
        tk.Button(frame, text="Renombrar perfil", command=self.rename_profile).pack(pady=5)
        tk.Button(frame, text="Eliminar perfil", command=self.delete_profile).pack(pady=5)

        tk.Label(frame, text="Módulos activados por defecto para este perfil:").pack(pady=10)
        self.profile_modules_frame = tk.Frame(frame)
        self.profile_modules_frame.pack()

    def _add_path_selector(self, parent, label):
        tk.Label(parent, text=label).pack()
        entry = tk.Entry(parent, width=60)
        entry.pack()
        tk.Button(parent, text="Seleccionar", command=lambda e=entry: self._select_folder(e)).pack()
        return entry

    def _select_folder(self, entry):
        path = filedialog.askdirectory()
        if path:
            entry.delete(0, tk.END)
            entry.insert(0, path)

    # ---------------------------------------------------------
    # TAB PRINCIPAL: FECHAS (con subpestañas)
    # ---------------------------------------------------------
    def build_processing_tab(self):
        self.sub_notebook = ttk.Notebook(self.tab_processing)
        self.sub_notebook.pack(fill="both", expand=True)

        self.sub_process = ttk.Frame(self.sub_notebook)
        self.sub_modules = ttk.Frame(self.sub_notebook)
        self.sub_logs = ttk.Frame(self.sub_notebook)

        self.sub_notebook.add(self.sub_process, text="Procesado")
        self.sub_notebook.add(self.sub_modules, text="Módulos")
        self.sub_notebook.add(self.sub_logs, text="Logs")

        self.build_sub_process_tab()
        self.build_sub_modules_tab()
        self.build_sub_logs_tab()

    # ---------------------------------------------------------
    # SUBPESTAÑA: PROCESADO
    # ---------------------------------------------------------
    def build_sub_process_tab(self):
        frame = self.sub_process

        tk.Label(frame, text="Offset de año:").pack()
        self.entry_offset = tk.Entry(frame)
        self.entry_offset.pack()

        tk.Label(frame, text="Módulos a procesar:").pack(pady=10)

        self.modules_frame = tk.Frame(frame)
        self.modules_frame.pack()

        tk.Button(frame, text="Procesar", command=self.run_processing).pack(pady=10)

    # ---------------------------------------------------------
    # SUBPESTAÑA: MÓDULOS (editor visual)
    # ---------------------------------------------------------
    def build_sub_modules_tab(self):
        frame = self.sub_modules

        tk.Label(frame, text="Juego del perfil actual:").pack()
        self.modules_game_label = tk.Label(frame, text="")
        self.modules_game_label.pack()

        self.modules_listbox = tk.Listbox(frame, width=50, height=15)
        self.modules_listbox.pack()
        self.modules_listbox.bind("<<ListboxSelect>>", self.on_module_selected)

        tk.Label(frame, text="Nombre del módulo:").pack()
        self.entry_mod_name = tk.Entry(frame, width=40)
        self.entry_mod_name.pack()

        tk.Label(frame, text="Ruta relativa:").pack()
        self.entry_mod_path = tk.Entry(frame, width=40)
        self.entry_mod_path.pack()

        tk.Label(frame, text="Extensiones ignoradas (coma):").pack()
        self.entry_mod_ignore = tk.Entry(frame, width=40)
        self.entry_mod_ignore.pack()

        tk.Button(frame, text="Añadir módulo", command=self.add_module).pack(pady=5)
        tk.Button(frame, text="Guardar cambios", command=self.save_module).pack(pady=5)
        tk.Button(frame, text="Eliminar módulo", command=self.delete_module).pack(pady=5)

    # ---------------------------------------------------------
    # SUBPESTAÑA: LOGS (informativa)
    # ---------------------------------------------------------
    def build_sub_logs_tab(self):
        frame = self.sub_logs
        tk.Label(frame, text="Logs por módulo").pack(pady=10)
        tk.Label(frame, text="Se guardan en la carpeta 'logs/<perfil>/<modulo>.log'.").pack()

    # ---------------------------------------------------------
    # TAB PRINCIPAL: VALIDACIÓN (con subpestañas)
    # ---------------------------------------------------------
    def build_validation_tab(self):
        notebook = ttk.Notebook(self.tab_validation)
        notebook.pack(fill="both", expand=True)

        self.tab_val_module = ttk.Frame(notebook)
        self.tab_val_full = ttk.Frame(notebook)

        notebook.add(self.tab_val_module, text="Validación por módulo")
        notebook.add(self.tab_val_full, text="Validación total")

        self.build_validation_module_tab()
        self.build_validation_full_tab()

    # ---------------------------------------------------------
    # SUBPESTAÑA VALIDACIÓN: POR MÓDULO
    # ---------------------------------------------------------
    def build_validation_module_tab(self):
        frame = self.tab_val_module

        tk.Label(frame, text="Módulo a validar (Juego vs Backup):").pack()
        self.validation_module_combo = ttk.Combobox(frame, values=[], state="readonly")
        self.validation_module_combo.pack()

        tk.Button(frame, text="Comparar ficheros", command=self.run_validation).pack(pady=10)

        self.validation_results = tk.Listbox(frame, width=80, height=20)
        self.validation_results.pack()

        tk.Button(frame, text="Ver diferencias", command=self.show_selected_diff).pack(pady=10)

    # ---------------------------------------------------------
    # SUBPESTAÑA VALIDACIÓN: TOTAL
    # ---------------------------------------------------------
    def build_validation_full_tab(self):
        frame = self.tab_val_full

        tk.Button(frame, text="Validar todos los módulos", command=self.run_full_validation).pack(pady=10)

        tk.Label(frame, text="Resumen por módulo:").pack()
        self.full_validation_summary = tk.Listbox(frame, width=80, height=10)
        self.full_validation_summary.pack()
        self.full_validation_summary.bind("<<ListboxSelect>>", self.on_full_validation_module_selected)

        tk.Label(frame, text="Detalles del módulo seleccionado (solo archivos problemáticos):").pack(pady=10)
        self.full_validation_details_list = tk.Listbox(frame, width=80, height=15)
        self.full_validation_details_list.pack()

        tk.Button(frame, text="Ver diff del archivo seleccionado", command=self.show_full_validation_diff).pack(pady=10)

    # ---------------------------------------------------------
    # EVENTOS DE PERFILES
    # ---------------------------------------------------------
    def on_profile_selected(self, event=None):
        name = self.profile_combo.get()
        self.current_profile = get_profile(name)

        if not self.current_profile:
            return

        self.entry_game_root.delete(0, tk.END)
        self.entry_game_root.insert(0, self.current_profile["game_root"])

        self.entry_mod_root.delete(0, tk.END)
        self.entry_mod_root.insert(0, self.current_profile["mod_root"])

        self.entry_backup_root.delete(0, tk.END)
        self.entry_backup_root.insert(0, self.current_profile["backup_root"])

        self.entry_offset.delete(0, tk.END)
        self.entry_offset.insert(0, str(self.current_profile["year_offset"]))

        self.load_profile_modules_checklist()
        self.load_modules_for_process()
        self.load_modules_for_profile_editor()
        self.load_modules_for_validation()

    def load_profile_modules_checklist(self):
        for w in self.profile_modules_frame.winfo_children():
            w.destroy()

        if not self.current_profile:
            return

        game_key = self.current_profile["game"]
        game_modules = self.modules.get(game_key, {})

        self.profile_module_vars = {}

        tk.Label(self.profile_modules_frame, text="Módulos por defecto del perfil:").pack(anchor="w")

        for module_name in game_modules.keys():
            var = tk.IntVar(value=1 if module_name in self.current_profile["modules"] else 0)
            chk = tk.Checkbutton(self.profile_modules_frame, text=module_name, variable=var)
            chk.pack(anchor="w")
            self.profile_module_vars[module_name] = var

    # ---------------------------------------------------------
    # MÓDULOS PARA PROCESADO
    # ---------------------------------------------------------
    def load_modules_for_process(self):
        for widget in self.modules_frame.winfo_children():
            widget.destroy()

        if not self.current_profile:
            return

        game_key = self.current_profile["game"]
        game_modules = self.modules.get(game_key, {})

        self.module_vars = {}

        for module_name in game_modules.keys():
            default_active = module_name in self.current_profile["modules"]
            var = tk.IntVar(value=1 if default_active else 0)
            chk = tk.Checkbutton(self.modules_frame, text=module_name, variable=var)
            chk.pack(anchor="w")
            self.module_vars[module_name] = var

    # ---------------------------------------------------------
    # EDITOR DE MÓDULOS
    # ---------------------------------------------------------
    def load_modules_for_profile_editor(self):
        self.modules_listbox.delete(0, tk.END)

        if not self.current_profile:
            return

        game_key = self.current_profile["game"]
        self.modules_game_label.config(text=game_key)

        game_modules = self.modules.get(game_key, {})

        for name in game_modules.keys():
            self.modules_listbox.insert(tk.END, name)

    def on_module_selected(self, event=None):
        sel = self.modules_listbox.curselection()
        if not sel or not self.current_profile:
            return

        name = self.modules_listbox.get(sel[0])
        game_key = self.current_profile["game"]

        if name not in self.modules.get(game_key, {}):
            return

        cfg = self.modules[game_key][name]

        self.entry_mod_name.delete(0, tk.END)
        self.entry_mod_name.insert(0, name)

        self.entry_mod_path.delete(0, tk.END)
        self.entry_mod_path.insert(0, cfg.get("path", ""))

        ignore = ", ".join(cfg.get("ignore_ext", []))
        self.entry_mod_ignore.delete(0, tk.END)
        self.entry_mod_ignore.insert(0, ignore)

    def add_module(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        name = self.entry_mod_name.get().strip()
        path = self.entry_mod_path.get().strip()
        ignore = [ext.strip() for ext in self.entry_mod_ignore.get().split(",") if ext.strip()]

        if not name or not path:
            messagebox.showerror("Error", "Nombre y ruta son obligatorios")
            return

        game_key = self.current_profile["game"]

        if game_key not in self.modules:
            self.modules[game_key] = {}

        self.modules[game_key][name] = {
            "path": path,
            "ignore_ext": ignore
        }

        self.save_modules_file()
        self.load_modules_for_profile_editor()
        self.load_modules_for_process()
        self.load_profile_modules_checklist()
        self.load_modules_for_validation()

    def save_module(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        name = self.entry_mod_name.get().strip()
        path = self.entry_mod_path.get().strip()
        ignore = [ext.strip() for ext in self.entry_mod_ignore.get().split(",") if ext.strip()]

        game_key = self.current_profile["game"]

        if name not in self.modules.get(game_key, {}):
            messagebox.showerror("Error", "El módulo no existe")
            return

        self.modules[game_key][name]["path"] = path
        self.modules[game_key][name]["ignore_ext"] = ignore

        self.save_modules_file()
        self.load_modules_for_profile_editor()
        self.load_modules_for_process()
        self.load_profile_modules_checklist()
        self.load_modules_for_validation()

    def delete_module(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        sel = self.modules_listbox.curselection()
        if not sel:
            return

        name = self.modules_listbox.get(sel[0])
        game_key = self.current_profile["game"]

        if name in self.modules.get(game_key, {}):
            del self.modules[game_key][name]

        self.save_modules_file()
        self.load_modules_for_profile_editor()
        self.load_modules_for_process()
        self.load_profile_modules_checklist()
        self.load_modules_for_validation()

    def save_modules_file(self):
        with open("modules.json", "w", encoding="utf-8") as f:
            json.dump(self.modules, f, indent=4)

    # ---------------------------------------------------------
    # GESTIÓN DE PERFILES
    # ---------------------------------------------------------
    def save_profile(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        self.current_profile["game_root"] = self.entry_game_root.get()
        self.current_profile["mod_root"] = self.entry_mod_root.get()
        self.current_profile["backup_root"] = self.entry_backup_root.get()

        try:
            self.current_profile["year_offset"] = int(self.entry_offset.get())
        except ValueError:
            self.current_profile["year_offset"] = 0

        if hasattr(self, "profile_module_vars"):
            selected_modules = [
                name for name, var in self.profile_module_vars.items() if var.get() == 1
            ]
            self.current_profile["modules"] = selected_modules

        update_profile(self.current_profile)
        messagebox.showinfo("OK", "Perfil guardado")

    def create_profile(self):
        new_profile = {
            "name": "Nuevo Perfil",
            "game": "CK3",
            "game_root": "",
            "mod_root": "",
            "backup_root": "",
            "year_offset": 10000,
            "modules": []
        }
        add_profile(new_profile)
        self.profile_combo["values"] = list_profiles()
        messagebox.showinfo("OK", "Perfil creado")

    def rename_profile(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        win = tk.Toplevel(self.root)
        win.title("Renombrar perfil")

        tk.Label(win, text="Nuevo nombre:").pack()
        entry = tk.Entry(win)
        entry.insert(0, self.current_profile["name"])
        entry.pack()

        def do_rename():
            new_name = entry.get().strip()
            if not new_name:
                messagebox.showerror("Error", "Nombre vacío")
                return

            profiles = load_profiles()

            if any(p["name"] == new_name for p in profiles):
                messagebox.showerror("Error", "Ya existe un perfil con ese nombre")
                return

            for p in profiles:
                if p["name"] == self.current_profile["name"]:
                    p["name"] = new_name
                    break

            save_profiles(profiles)

            self.current_profile["name"] = new_name
            self.profile_combo["values"] = list_profiles()
            self.profile_combo.set(new_name)

            win.destroy()

        tk.Button(win, text="Aceptar", command=do_rename).pack(pady=5)

    def delete_profile(self):
        if not self.current_profile:
            messagebox.showerror("Error", "No hay perfil seleccionado")
            return

        name = self.current_profile["name"]

        if not messagebox.askyesno("Confirmar", f"¿Eliminar el perfil '{name}'?"):
            return

        from utils.profile_ops import delete_profile as delete_profile_fn
        delete_profile_fn(name)

        self.current_profile = None
        self.profile_combo["values"] = list_profiles()
        self.profile_combo.set("")

        self.entry_game_root.delete(0, tk.END)
        self.entry_mod_root.delete(0, tk.END)
        self.entry_backup_root.delete(0, tk.END)
        self.entry_offset.delete(0, tk.END)

        for w in self.profile_modules_frame.winfo_children():
            w.destroy()
        for w in self.modules_frame.winfo_children():
            w.destroy()

        self.module_vars = {}
        self.validation_module_combo["values"] = []
        self.validation_results.delete(0, tk.END)
        self.validation_diffs.clear()
        self.full_validation_summary.delete(0, tk.END)
        self.full_validation_details_list.delete(0, tk.END)
        self.full_validation_diffs.clear()
        self.full_validation_details.clear()

    # ---------------------------------------------------------
    # PROCESADO
    # ---------------------------------------------------------
    def run_processing(self):
        if not self.current_profile:
            messagebox.showerror("Error", "Selecciona un perfil")
            return

        game_root = self.current_profile["game_root"]
        mod_root = self.current_profile["mod_root"]
        backup_root = self.current_profile["backup_root"]
        game_key = self.current_profile["game"]
        profile_name = self.current_profile["name"]

        try:
            offset = int(self.entry_offset.get())
        except ValueError:
            messagebox.showerror("Error", "Offset inválido")
            return

        for module_name, var in self.module_vars.items():
            if var.get() == 1:
                process_module(
                    game_key,
                    module_name,
                    game_root,
                    mod_root,
                    backup_root,
                    offset,
                    profile_name
                )

        messagebox.showinfo("OK", "Procesado completado")

    # ---------------------------------------------------------
    # VALIDACIÓN: CARGA DE MÓDULOS
    # ---------------------------------------------------------
    def load_modules_for_validation(self):
        if not self.current_profile:
            self.validation_module_combo["values"] = []
            return

        game_key = self.current_profile["game"]
        game_modules = self.modules.get(game_key, {})
        self.validation_module_combo["values"] = list(game_modules.keys())
        if game_modules:
            self.validation_module_combo.current(0)

    # ---------------------------------------------------------
    # VALIDACIÓN POR MÓDULO
    # ---------------------------------------------------------
    def run_validation(self):
        self.validation_results.delete(0, tk.END)
        self.validation_diffs.clear()

        if not self.current_profile:
            messagebox.showerror("Error", "Selecciona un perfil")
            return

        module_name = self.validation_module_combo.get()
        if not module_name:
            messagebox.showerror("Error", "Selecciona un módulo")
            return

        game_key = self.current_profile["game"]
        game_modules = self.modules.get(game_key, {})
        if module_name not in game_modules:
            messagebox.showerror("Error", "Módulo no encontrado")
            return

        rel_path = game_modules[module_name]["path"]
        game_root = self.current_profile["game_root"]
        backup_root = self.current_profile["backup_root"]

        if not game_root or not backup_root:
            messagebox.showerror("Error", "Configura rutas de juego y backup en el perfil")
            return

        src_game = os.path.join(game_root, rel_path)
        src_backup = os.path.join(backup_root, rel_path)

        game_files = {}
        backup_files = {}

        if os.path.isdir(src_game):
            for base, _, files in os.walk(src_game):
                for f in files:
                    full = os.path.join(base, f)
                    rel = os.path.relpath(full, src_game)
                    game_files[rel] = full

        if os.path.isdir(src_backup):
            for base, _, files in os.walk(src_backup):
                for f in files:
                    full = os.path.join(base, f)
                    rel = os.path.relpath(full, src_backup)
                    backup_files[rel] = full

        all_keys = sorted(set(game_files.keys()) | set(backup_files.keys()))

        for rel in all_keys:
            g = game_files.get(rel)
            b = backup_files.get(rel)

            if g and b:
                same, diff_lines = self.compare_files(g, b)
                if same:
                    display = f"[=] {rel} — IGUAL"
                else:
                    display = f"[!] {rel} — CAMBIADO"
                    self.validation_diffs[rel] = diff_lines
            elif g and not b:
                display = f"[+] {rel} — SOLO EN JUEGO"
            else:
                display = f"[-] {rel} — SOLO EN BACKUP"

            self.validation_results.insert(tk.END, display)

    def compare_files(self, game_path, backup_path):
        try:
            with open(game_path, "r", encoding="utf-8") as f:
                game_lines = f.readlines()
        except UnicodeDecodeError:
            with open(game_path, "r", encoding="latin-1") as f:
                game_lines = f.readlines()

        try:
            with open(backup_path, "r", encoding="utf-8") as f:
                backup_lines = f.readlines()
        except UnicodeDecodeError:
            with open(backup_path, "r", encoding="latin-1") as f:
                backup_lines = f.readlines()

        if game_lines == backup_lines:
            return True, []

        diff = list(difflib.unified_diff(
            backup_lines, game_lines,
            fromfile="backup",
            tofile="game",
            lineterm=""
        ))
        return False, diff

    def show_selected_diff(self):
        sel = self.validation_results.curselection()
        if not sel:
            return

        line = self.validation_results.get(sel[0])
        if "CAMBIADO" not in line:
            messagebox.showinfo("Info", "Solo hay diff para archivos marcados como CAMBIADO")
            return

        rel = line.split(" ", 1)[1].split(" — ")[0].strip()
        if rel not in self.validation_diffs:
            messagebox.showerror("Error", "No se encontró diff para este archivo")
            return

        diff_lines = self.validation_diffs[rel]
        self.show_diff_window(rel, diff_lines)

    def show_diff_window(self, rel, diff_lines):
        win = tk.Toplevel(self.root)
        win.title(f"Diferencias: {rel}")
        text = tk.Text(win, width=120, height=40)
        text.pack(fill="both", expand=True)

        for line in diff_lines:
            if line.startswith("+") and not line.startswith("+++"):
                text.insert(tk.END, line, "added")
            elif line.startswith("-") and not line.startswith("---"):
                text.insert(tk.END, line, "removed")
            else:
                text.insert(tk.END, line)
            text.insert(tk.END, "\n")

        text.tag_config("added", foreground="green")
        text.tag_config("removed", foreground="red")

        text.config(state="disabled")

    # ---------------------------------------------------------
    # VALIDACIÓN TOTAL
    # ---------------------------------------------------------
    def run_full_validation(self):
        self.full_validation_summary.delete(0, tk.END)
        self.full_validation_details_list.delete(0, tk.END)
        self.full_validation_diffs.clear()
        self.full_validation_details.clear()

        if not self.current_profile:
            messagebox.showerror("Error", "Selecciona un perfil")
            return

        game_key = self.current_profile["game"]
        game_modules = self.modules.get(game_key, {})

        if not game_modules:
            messagebox.showerror("Error", "No hay módulos definidos para este juego")
            return

        game_root = self.current_profile["game_root"]
        backup_root = self.current_profile["backup_root"]

        if not game_root or not backup_root:
            messagebox.showerror("Error", "Configura rutas de juego y backup en el perfil")
            return

        summary = []

        for module_name, cfg in game_modules.items():
            rel_path = cfg["path"]
            src_game = os.path.join(game_root, rel_path)
            src_backup = os.path.join(backup_root, rel_path)

            game_files = {}
            backup_files = {}

            if os.path.isdir(src_game):
                for base, _, files in os.walk(src_game):
                    for f in files:
                        full = os.path.join(base, f)
                        rel = os.path.relpath(full, src_game)
                        game_files[rel] = full

            if os.path.isdir(src_backup):
                for base, _, files in os.walk(src_backup):
                    for f in files:
                        full = os.path.join(base, f)
                        rel = os.path.relpath(full, src_backup)
                        backup_files[rel] = full

            all_keys = set(game_files.keys()) | set(backup_files.keys())

            changed = 0
            only_game = 0
            only_backup = 0

            details = []

            for rel in all_keys:
                g = game_files.get(rel)
                b = backup_files.get(rel)

                if g and b:
                    same, diff_lines = self.compare_files(g, b)
                    if not same:
                        changed += 1
                        key = f"{module_name}:{rel}"
                        self.full_validation_diffs[key] = diff_lines
                        details.append(f"[!] {rel} — CAMBIADO")
                elif g and not b:
                    only_game += 1
                    details.append(f"[+] {rel} — SOLO EN JUEGO")
                elif b and not g:
                    only_backup += 1
                    details.append(f"[-] {rel} — SOLO EN BACKUP")

            summary.append((module_name, changed, only_game, only_backup))
            self.full_validation_details[module_name] = details

        for module_name, changed, only_game, only_backup in summary:
            line = f"{module_name} — Cambiados:{changed}  Nuevos:{only_game}  Eliminados:{only_backup}"
            self.full_validation_summary.insert(tk.END, line)

    def on_full_validation_module_selected(self, event=None):
        sel = self.full_validation_summary.curselection()
        if not sel:
            return

        line = self.full_validation_summary.get(sel[0])
        module_name = line.split(" — ")[0].strip()

        self.full_validation_details_list.delete(0, tk.END)

        details = self.full_validation_details.get(module_name, [])
        for d in details:
            self.full_validation_details_list.insert(tk.END, d)

    def show_full_validation_diff(self):
        sel = self.full_validation_details_list.curselection()
        if not sel:
            return

        line = self.full_validation_details_list.get(sel[0])
        if "CAMBIADO" not in line:
            messagebox.showinfo("Info", "Solo hay diff para archivos marcados como CAMBIADO")
            return

        rel = line.split(" ", 1)[1].split(" — ")[0].strip()

        sel_mod = self.full_validation_summary.curselection()
        if not sel_mod:
            messagebox.showerror("Error", "Selecciona primero un módulo en el resumen")
            return

        mod_line = self.full_validation_summary.get(sel_mod[0])
        module_name = mod_line.split(" — ")[0].strip()

        key = f"{module_name}:{rel}"
        if key not in self.full_validation_diffs:
            messagebox.showerror("Error", "No se encontró diff para este archivo")
            return

        diff_lines = self.full_validation_diffs[key]
        self.show_diff_window(f"{module_name}:{rel}", diff_lines)


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = ModToolApp(root)
    root.mainloop()
